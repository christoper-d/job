﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace datos
{
    internal class conexion
    {
        private string Base;
        private string servidor;
        private string user;
        private string clave;
        public static conexion conn = null;

        private conexion()
        {
            this.Base = "loginPrueba";
            this.servidor = "DESKTOP-PPLNINA";
            this.user = "christoper";
            this.clave = "DYF@CHRISTOPER";
        }

        public SqlConnection newCon()
        {
            SqlConnection con = new SqlConnection();
            try
            {
                con.ConnectionString = "Server=" + this.servidor + "; Database=" + this.Base + "; User Id=" + this.user + "; Password=" + this.clave;
            }
            catch (Exception ex)
            {
                con = null;
                throw ex;
            }
            return con;
        }

        public static conexion GetConexion()
        {
            if (conn == null)
            {
                conn = new conexion();
            }
            return conn;
        }
    }
}
