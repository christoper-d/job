﻿using logica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace login
{
    public partial class loginForm : Form
    {
        l_login l_Login = new l_login();
        l_User l_User = new l_User();
        public loginForm()
        {
            InitializeComponent();
        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            string name = txtUser.Text;
            string password = txtPassword.Text;


            if (l_Login.login(name, password))
            {
                lbMensaje.Text = "Inicio de sesion correcto";
                lbMensaje.ForeColor = Color.Green;

                DialogResult = DialogResult.OK;
                Close();
            }
            else
            {
                lbMensaje.Text = "error al inicar sesion";
                lbMensaje.ForeColor = Color.Red;
                MessageBox.Show("error al inicar sesion");
            }
        }

        private void btnRecuperar_Click(object sender, EventArgs e)
        {
            recuperarForm recuperarForm = new recuperarForm();
            recuperarForm.ShowDialog();
        }

        private void loginForm_Load(object sender, EventArgs e)
        {

        }
    }
}
