﻿namespace login
{
    partial class recuperarForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnIrLogin = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnForConfirmNewPassword = new System.Windows.Forms.Button();
            this.lbMensajeForNewPassword = new System.Windows.Forms.Label();
            this.txtNewPassword = new System.Windows.Forms.TextBox();
            this.txtForNewPassword = new System.Windows.Forms.Label();
            this.btnBuscarUsuario = new System.Windows.Forms.Button();
            this.lbforRecuperar = new System.Windows.Forms.Label();
            this.txtUser = new System.Windows.Forms.TextBox();
            this.lbForUser = new System.Windows.Forms.Label();
            this.lbMensaje = new System.Windows.Forms.Label();
            this.lbforLastPassword = new System.Windows.Forms.Label();
            this.txtLastPassword = new System.Windows.Forms.TextBox();
            this.lbMensajeForLastPassword = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnIrLogin
            // 
            this.btnIrLogin.Location = new System.Drawing.Point(115, 403);
            this.btnIrLogin.Name = "btnIrLogin";
            this.btnIrLogin.Size = new System.Drawing.Size(94, 33);
            this.btnIrLogin.TabIndex = 25;
            this.btnIrLogin.Text = "ir a Login";
            this.btnIrLogin.UseVisualStyleBackColor = true;
            this.btnIrLogin.Visible = false;
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(172, 403);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(112, 34);
            this.btnCancelar.TabIndex = 24;
            this.btnCancelar.Text = "cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnForConfirmNewPassword
            // 
            this.btnForConfirmNewPassword.Location = new System.Drawing.Point(42, 403);
            this.btnForConfirmNewPassword.Name = "btnForConfirmNewPassword";
            this.btnForConfirmNewPassword.Size = new System.Drawing.Size(112, 34);
            this.btnForConfirmNewPassword.TabIndex = 23;
            this.btnForConfirmNewPassword.Text = "confirmar";
            this.btnForConfirmNewPassword.UseVisualStyleBackColor = true;
            this.btnForConfirmNewPassword.Visible = false;
            this.btnForConfirmNewPassword.Click += new System.EventHandler(this.btnForConfirmNewPassword_Click);
            // 
            // lbMensajeForNewPassword
            // 
            this.lbMensajeForNewPassword.AutoSize = true;
            this.lbMensajeForNewPassword.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMensajeForNewPassword.Location = new System.Drawing.Point(46, 333);
            this.lbMensajeForNewPassword.Name = "lbMensajeForNewPassword";
            this.lbMensajeForNewPassword.Size = new System.Drawing.Size(0, 20);
            this.lbMensajeForNewPassword.TabIndex = 22;
            this.lbMensajeForNewPassword.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtNewPassword
            // 
            this.txtNewPassword.Location = new System.Drawing.Point(42, 357);
            this.txtNewPassword.Name = "txtNewPassword";
            this.txtNewPassword.Size = new System.Drawing.Size(229, 20);
            this.txtNewPassword.TabIndex = 21;
            this.txtNewPassword.Visible = false;
            // 
            // txtForNewPassword
            // 
            this.txtForNewPassword.AutoSize = true;
            this.txtForNewPassword.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtForNewPassword.Location = new System.Drawing.Point(12, 312);
            this.txtForNewPassword.Name = "txtForNewPassword";
            this.txtForNewPassword.Size = new System.Drawing.Size(121, 21);
            this.txtForNewPassword.TabIndex = 20;
            this.txtForNewPassword.Text = "New Password";
            this.txtForNewPassword.Visible = false;
            // 
            // btnBuscarUsuario
            // 
            this.btnBuscarUsuario.Location = new System.Drawing.Point(97, 162);
            this.btnBuscarUsuario.Name = "btnBuscarUsuario";
            this.btnBuscarUsuario.Size = new System.Drawing.Size(112, 34);
            this.btnBuscarUsuario.TabIndex = 19;
            this.btnBuscarUsuario.Text = "Buscar Usuario";
            this.btnBuscarUsuario.UseVisualStyleBackColor = true;
            this.btnBuscarUsuario.Click += new System.EventHandler(this.btnBuscarUsuario_Click);
            // 
            // lbforRecuperar
            // 
            this.lbforRecuperar.AutoSize = true;
            this.lbforRecuperar.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbforRecuperar.Location = new System.Drawing.Point(61, 31);
            this.lbforRecuperar.Name = "lbforRecuperar";
            this.lbforRecuperar.Size = new System.Drawing.Size(176, 42);
            this.lbforRecuperar.TabIndex = 18;
            this.lbforRecuperar.Text = "Ingrese su usuario para \r\nrecuperar contraseña";
            // 
            // txtUser
            // 
            this.txtUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtUser.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUser.Location = new System.Drawing.Point(97, 112);
            this.txtUser.Name = "txtUser";
            this.txtUser.Size = new System.Drawing.Size(112, 22);
            this.txtUser.TabIndex = 17;
            // 
            // lbForUser
            // 
            this.lbForUser.AutoSize = true;
            this.lbForUser.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbForUser.Location = new System.Drawing.Point(93, 88);
            this.lbForUser.Name = "lbForUser";
            this.lbForUser.Size = new System.Drawing.Size(44, 21);
            this.lbForUser.TabIndex = 16;
            this.lbForUser.Text = "User";
            // 
            // lbMensaje
            // 
            this.lbMensaje.AutoSize = true;
            this.lbMensaje.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMensaje.Location = new System.Drawing.Point(12, 209);
            this.lbMensaje.Name = "lbMensaje";
            this.lbMensaje.Size = new System.Drawing.Size(0, 20);
            this.lbMensaje.TabIndex = 26;
            this.lbMensaje.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbforLastPassword
            // 
            this.lbforLastPassword.AutoSize = true;
            this.lbforLastPassword.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbforLastPassword.Location = new System.Drawing.Point(12, 234);
            this.lbforLastPassword.Name = "lbforLastPassword";
            this.lbforLastPassword.Size = new System.Drawing.Size(108, 21);
            this.lbforLastPassword.TabIndex = 27;
            this.lbforLastPassword.Text = "LastPassword";
            this.lbforLastPassword.Visible = false;
            // 
            // txtLastPassword
            // 
            this.txtLastPassword.Location = new System.Drawing.Point(42, 278);
            this.txtLastPassword.Name = "txtLastPassword";
            this.txtLastPassword.Size = new System.Drawing.Size(229, 20);
            this.txtLastPassword.TabIndex = 28;
            this.txtLastPassword.Visible = false;
            // 
            // lbMensajeForLastPassword
            // 
            this.lbMensajeForLastPassword.AutoSize = true;
            this.lbMensajeForLastPassword.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMensajeForLastPassword.Location = new System.Drawing.Point(38, 255);
            this.lbMensajeForLastPassword.Name = "lbMensajeForLastPassword";
            this.lbMensajeForLastPassword.Size = new System.Drawing.Size(0, 20);
            this.lbMensajeForLastPassword.TabIndex = 29;
            this.lbMensajeForLastPassword.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // recuperarForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(308, 451);
            this.Controls.Add(this.lbMensajeForLastPassword);
            this.Controls.Add(this.txtLastPassword);
            this.Controls.Add(this.lbforLastPassword);
            this.Controls.Add(this.lbMensaje);
            this.Controls.Add(this.btnIrLogin);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnForConfirmNewPassword);
            this.Controls.Add(this.lbMensajeForNewPassword);
            this.Controls.Add(this.txtNewPassword);
            this.Controls.Add(this.txtForNewPassword);
            this.Controls.Add(this.btnBuscarUsuario);
            this.Controls.Add(this.lbforRecuperar);
            this.Controls.Add(this.txtUser);
            this.Controls.Add(this.lbForUser);
            this.Name = "recuperarForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "recuperar";
            this.Load += new System.EventHandler(this.recuperar_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnIrLogin;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnForConfirmNewPassword;
        private System.Windows.Forms.Label lbMensajeForNewPassword;
        private System.Windows.Forms.TextBox txtNewPassword;
        private System.Windows.Forms.Label txtForNewPassword;
        private System.Windows.Forms.Button btnBuscarUsuario;
        private System.Windows.Forms.Label lbforRecuperar;
        private System.Windows.Forms.TextBox txtUser;
        private System.Windows.Forms.Label lbForUser;
        private System.Windows.Forms.Label lbMensaje;
        private System.Windows.Forms.Label lbforLastPassword;
        private System.Windows.Forms.TextBox txtLastPassword;
        private System.Windows.Forms.Label lbMensajeForLastPassword;
    }
}