﻿using logica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace login
{
    public partial class main : Form
    {
        l_User l_User = new l_User();
        

        public main()
        {
            InitializeComponent();
        }

        public void ls_users()
        {
            
            allUsersData.DataSource = l_User.ls_users();
        }
        public void saludo()
        {
            lbUser.Text = l_User.GetUserName();
        }

        private void main_Load(object sender, EventArgs e)
        {
            loginForm login = new loginForm();
            if (login.ShowDialog() != DialogResult.OK)
            {
                Application.Exit();
            }

            this.ls_users();
            this.saludo();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
